/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;

/**
 *
 * @author Jalal
 * @co-author Subhaan, Tasnim, Simon
 */
public class ConnectDB {

    // this is for connecting the sql file of Trafficdata with the jdbc
    public static Connection getConnection() {

        String urlSQLite = "jdbc:sqlite:TrafficData.db";

        //it will launch the driver manager first to get connected
        try {
            Driver driverSQLite = new org.sqlite.JDBC();
            DriverManager.registerDriver(driverSQLite);
            System.out.println("SQLite Driver loaded up!");
        } catch (Exception e) {
            System.out.println("There is a problem with the SQLite Driver:" + e.getMessage());
        }

        Connection connection = null;

        //after the SQl driver manager its loaded the database will be connnected with urlSQLite
        try {
            connection = DriverManager.getConnection(urlSQLite);
            System.out.println("Connected to the database!");
        } catch (Exception e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }

        return connection;
    }

    //this is for connecting the User into jdbc
    public static Connection DBConnectionUser() {

        String urlSQLite = "jdbc:sqlite:User.db";

        //launch the sql driver manager 
        try {
            Driver driverSQLite = new org.sqlite.JDBC();
            DriverManager.registerDriver(driverSQLite);
            System.out.println("SQLite Driver loaded up!");
        } catch (Exception e) {
            System.out.println("There is a problem with the SQLite Driver:" + e.getMessage());
        }

        Connection connection = null;

        // once loaded the database will be connected with urlSQLite
        try {
            connection = DriverManager.getConnection(urlSQLite);
            System.out.println("Connected to the database!");
        } catch (Exception e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
        return connection;
    }

}
