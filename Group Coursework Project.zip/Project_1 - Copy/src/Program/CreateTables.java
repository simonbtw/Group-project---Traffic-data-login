/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author Jalal
 * @co-author Subhaan, Tasnim, Simon
 */
public class CreateTables {

    // here it will create the table of Traffic data
    public static void createTrafficData() {

        //this is for once you run the program the information will be inserted into your database
        Connection connection = ConnectDB.getConnection();

        //this are the fields name of the table that will be created
        String sql = "CREATE TABLE if not exists TrafficData"
                + "("
                + "id INTEGER PRIMARY KEY, "
                + "Direction_of_travel VARCHAR (15),"
                + "Count_year INTEGER (11),"
                + "Count_point_hour INTEGR (6),"
                + "Local_authority_name VARCHAR (15),"
                + "Road_name VARCHAR (25),"
                + "Road_type VARCHAR (25),"
                + "Start_Junction_road_name VARCHAR (25),"
                + "End_Junction_road_name VARCHAR (25),"
                + "Road_Easting INTEGER (11),"
                + "Road_Northing INTEGER (11),"
                + "Road_Latitude INTEGER (11),"
                + "Road_Longitude INTEGER (11),"
                + "Link_length_km INTEGER (6),"
                + "Link_length_miles INTEGER (6),"
                + "Pedal_cycles INTEGER (6),"
                + "Two_wheeled_motor_vehicles INTEGER (6),"
                + "Cars_and_Taxis INTEGER (6),"
                + "Buses_and_Coaches INTEGR (6),"
                + "Large_goods_vehicles INTEGER (6),"
                + "Heavy_goods_vehicles_2_rigid_axle INTEGER (6),"
                + "Heavy_goods_vehicles_3_rigid_axle INTEGER (6),"
                + "Heavy_goods_vehicles_4_or_more_rigid_axle INTEGER (6),"
                + "Heavy_goods_vehicles_3_or_4_articulated_axle INTEGR (6),"
                + "Heavy_goods_vehicles_5_articulated_axle INTEGR (6),"
                + "Heavy_goods_vehicles_6_articulated_axle INTEGER (6),"
                + "All_heavy_goods_vehicles INTEGR (6),"
                + "All_motor_vehicles INTEGR (6)"
                + ")";

        //the table is will be created after its connected 
        try {
            Statement sqlStatement = connection.createStatement();
            sqlStatement.executeUpdate(sql);
            System.out.println("Traffic data table created!");
        } catch (Exception e) {
            System.out.println("Error creating Traffic data table!" + e.getMessage());
        }
    }
}
