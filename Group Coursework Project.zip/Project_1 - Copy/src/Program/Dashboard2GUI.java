/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.jdbc.JDBCCategoryDataset;

/**
 *
 * @author Simon
 */
public class Dashboard2GUI extends javax.swing.JFrame {

    /**
     * Creates new form Dashboard2GUI
     */
    public Dashboard2GUI() {
        initComponents();
    }

    Dashboard2GUI(String Username) {
        initComponents();
        UsernameContent.setText(Username);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BackAdminPanel = new javax.swing.JButton();
        viewDashboard = new javax.swing.JPanel();
        Caerphillybtn = new javax.swing.JButton();
        minorbtn = new javax.swing.JButton();
        UsernameContent1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        UsernameContent = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BackAdminPanel.setBackground(new java.awt.Color(204, 204, 204));
        BackAdminPanel.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        BackAdminPanel.setText("Back to AdminPanel");
        BackAdminPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackAdminPanelActionPerformed(evt);
            }
        });

        viewDashboard.setBackground(new java.awt.Color(204, 204, 204));
        viewDashboard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        viewDashboard.setLayout(new java.awt.BorderLayout());

        Caerphillybtn.setBackground(new java.awt.Color(204, 204, 204));
        Caerphillybtn.setText("All Heavy & Motor Vehicles");
        Caerphillybtn.setBorder(null);
        Caerphillybtn.setBorderPainted(false);
        Caerphillybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CaerphillybtnActionPerformed(evt);
            }
        });

        minorbtn.setBackground(new java.awt.Color(204, 204, 204));
        minorbtn.setText("Travel Directions(KM,Miles)");
        minorbtn.setBorder(null);
        minorbtn.setBorderPainted(false);
        minorbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minorbtnActionPerformed(evt);
            }
        });

        UsernameContent1.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        UsernameContent1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Program/logo.png"))); // NOI18N

        jLabel3.setText("Motor vehicles by Traffic Directions and Local Authority Data");

        UsernameContent.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        UsernameContent.setText("Username");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(UsernameContent)
                    .addComponent(jLabel3))
                .addContainerGap(176, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(UsernameContent)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setText("Show Table");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                        .addComponent(UsernameContent1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(viewDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Caerphillybtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(minorbtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(BackAdminPanel)
                                .addGap(23, 23, 23)))))
                .addGap(60, 60, 60))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UsernameContent1))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(minorbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Caerphillybtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BackAdminPanel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(viewDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackAdminPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackAdminPanelActionPerformed
        //displays the AdminPanel
        AdminPanelGUI adminpanelGUI = new AdminPanelGUI(UsernameContent.getText());
        adminpanelGUI.setVisible(true);
        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_BackAdminPanelActionPerformed

    private void CaerphillybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CaerphillybtnActionPerformed
        try {
            String query = "SELECT Local_authority_name, All_Heavy_goods_vehicles, All_motor_vehicles  FROM TrafficData \"WHERE Local_authority_name IN ('Caerphilly', 'London', 'Birmigham', 'Leeds', 'Manchester')\" GROUP BY Local_authority_name ";
            drawBar(query);
        } catch (SQLException ex) {
            Logger.getLogger(Dashboard2GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_CaerphillybtnActionPerformed

    private void minorbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minorbtnActionPerformed
        try {
            String query = "SELECT Direction_of_travel, Link_length_km, Link_length_miles FROM TrafficData \"WHERE Direction_of_travel IN ('North', 'South', 'West', 'East')\"  GROUP BY Direction_of_travel";
            drawBar(query);
        } catch (SQLException ex) {
            Logger.getLogger(Dashboard2GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_minorbtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        showTable();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard2GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard2GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard2GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard2GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Creates and displays the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard2GUI().setVisible(true);
            }
        });
    }

    public void drawBar(String query) throws SQLException {
        Connection con = ConnectDB.getConnection();
        Statement stmnt = null;
        JDBCCategoryDataset dataset = null;
        try {

            String sql = query;

            dataset = new JDBCCategoryDataset(con, sql);

            System.out.println("dataset cols and rows : " + dataset.getColumnCount() + " " + dataset.getRowCount());

        } catch (SQLException ex) {
            System.err.println("SQLException" + ex.getMessage());
        } finally {
            if (stmnt != null) {
                try {
                    stmnt.close();
                } catch (SQLException ex) {
                    System.err.println("SQLException" + ex.getMessage());
                }
            }
        }

        JFreeChart chart = ChartFactory.createBarChart("Traffic Data", "Local Authority ", "Number Of Vehicles", dataset, PlotOrientation.HORIZONTAL, false, true, false);

        CategoryPlot plot = chart.getCategoryPlot();
        ChartPanel chartpanel = new ChartPanel(chart);

        viewDashboard.removeAll();
        viewDashboard.add(chartpanel, BorderLayout.CENTER);
        viewDashboard.validate();
    }

    private void showTable() {
        System.out.println("Show All Button clicked");
        Connection con = ConnectDB.getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = con.createStatement();

            rs = stmt.executeQuery("Select Direction_of_travel, Local_authority_name, Link_length_km, Link_length_miles, All_motor_vehicles, All_Heavy_goods_vehicles"
                    + " from TrafficData");
            // get columns info
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            // for changing column and row model
            DefaultTableModel tm = (DefaultTableModel) jTable1.getModel();

            // clear existing columns 
            tm.setColumnCount(0);

            // add specified columns to table
            for (int i = 1; i <= columnCount; i++) {
                tm.addColumn(rsmd.getColumnName(i));
            }

            // clear existing rows
            tm.setRowCount(0);

            // add rows to table
            while (rs.next()) {
                String[] a = new String[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    a[i] = rs.getString(i + 1);
                }
                tm.addRow(a);
            }
            tm.fireTableDataChanged();

            rs.close();

        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    System.err.println("SQLException: " + e.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.err.println("SQLException: " + e.getMessage());
                }
            }
        }

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackAdminPanel;
    private javax.swing.JButton Caerphillybtn;
    private javax.swing.JLabel UsernameContent;
    private javax.swing.JLabel UsernameContent1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton minorbtn;
    private javax.swing.JPanel viewDashboard;
    // End of variables declaration//GEN-END:variables
}
