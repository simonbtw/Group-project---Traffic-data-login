/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Jalal
 * @co-author Subhaan, Tasnim, Simon
 */
public class TrafficDataTable {

    private static Connection connection = ConnectDB.getConnection();

    //will insert all your databsse inot the created table
    public static void insert(int id, String Direction_of_travel, int Count_year, int Count_point_hour, String Local_authority_name,
            String Road_name, String Road_type, String Start_Junction_road_name, String End_Junction_road_name,
            int Road_Easting, int Road_Northing, double Road_Latitude, double Road_Longitude, double Link_length_km,
            double Link_length_miles, int Pedal_cycles, int Two_wheeled_motor_vehicles, int Cars_and_Taxis, int Buses_and_Coaches,
            int Large_goods_vehicles, int Heavy_goods_vehicles_2_rigid_axle, int Heavy_goods_vehicles_3_rigid_axle, int Heavy_goods_vehicles_4_or_more_rigid_axle,
            int Heavy_goods_vehicles_3_or_4_articulated_axle, int Heavy_goods_vehicles_5_articulated_axle, int Heavy_goods_vehicles_6_articulated_axle,
            int All_heavy_goods_vehicles, int All_motor_vehicles) {

        String sql = "INSERT INTO TrafficData (id, Direction_of_travel, Count_year, Count_point_hour, Local_authority_name, Road_name, Road_type, Start_Junction_road_name, End_Junction_road_name, Road_Easting, Road_Northing, Road_Latitude, Road_Longitude, Link_length_km, Link_length_miles, Pedal_cycles, Two_wheeled_motor_vehicles, Cars_and_Taxis, Buses_and_Coaches, Large_goods_vehicles, Heavy_goods_vehicles_2_rigid_axle, Heavy_goods_vehicles_3_rigid_axle, Heavy_goods_vehicles_4_or_more_rigid_axle, Heavy_goods_vehicles_3_or_4_articulated_axle, Heavy_goods_vehicles_5_articulated_axle, Heavy_goods_vehicles_6_articulated_axle, All_heavy_goods_vehicles, All_motor_vehicles) VALUES"
                + "("
                + "'" + id + "',"
                + "'" + Direction_of_travel + "',"
                + "'" + Count_year + "',"
                + "'" + Count_point_hour + "',"
                + "'" + Local_authority_name + "',"
                + "'" + Road_name + "',"
                + "'" + Road_type + "',"
                + "'" + Start_Junction_road_name + "',"
                + "'" + End_Junction_road_name + "',"
                + "'" + Road_Easting + "',"
                + "'" + Road_Northing + "',"
                + "'" + Road_Latitude + "',"
                + "'" + Road_Longitude + "',"
                + "'" + Link_length_km + "',"
                + "'" + Link_length_miles + "',"
                + "'" + Pedal_cycles + "',"
                + "'" + Two_wheeled_motor_vehicles + "',"
                + "'" + Cars_and_Taxis + "',"
                + "'" + Buses_and_Coaches + "',"
                + "'" + Large_goods_vehicles + "',"
                + "'" + Heavy_goods_vehicles_2_rigid_axle + "',"
                + "'" + Heavy_goods_vehicles_3_rigid_axle + "',"
                + "'" + Heavy_goods_vehicles_4_or_more_rigid_axle + "',"
                + "'" + Heavy_goods_vehicles_3_or_4_articulated_axle + "',"
                + "'" + Heavy_goods_vehicles_5_articulated_axle + "',"
                + "'" + Heavy_goods_vehicles_6_articulated_axle + "',"
                + "'" + All_heavy_goods_vehicles + "',"
                + "'" + All_motor_vehicles + "'"
                + ")";

        //when you insert the name of the road will be shown into the running output
        try {
            Statement statement = connection.createStatement();
            statement.execute(sql);
            System.out.println("TrafficData " + Road_name + " inserted!");
            
        // if the daata is already in the system the exception will applied
        } catch (Exception e) {
            System.out.println("Error while inserting into Traffic data table:" + e.getMessage());
        }
    }

    //this is for the csv reader file  to insert the data in the table
    public static void batchInsert(ArrayList<String> input) {

        for (String currentLine : input) {
            String[] lineArray = currentLine.split(",");
            int id = Integer.parseInt(lineArray[0]);
            String Direction_of_travel = lineArray[1];
            int Count_year = Integer.parseInt(lineArray[2]);
            int Count_point_hour = Integer.parseInt(lineArray[3]);
            String Local_authority_name = lineArray[4];
            String Road_name = lineArray[5];
            String Road_type = lineArray[6];
            String Start_Junction_road_name = lineArray[7];
            String End_Junction_road_name = lineArray[8];
            int Road_Easting = Integer.parseInt(lineArray[9]);
            int Road_Northing = Integer.parseInt(lineArray[10]);
            double Road_Latitude = Double.parseDouble(lineArray[11]);
            double Road_Longitude = Double.parseDouble(lineArray[12]);
            double Link_length_km = Double.parseDouble(lineArray[13]);
            double Link_length_miles = Double.parseDouble(lineArray[14]);
            int Pedal_cycles = Integer.parseInt(lineArray[15]);
            int Two_wheeled_motor_vehicles = Integer.parseInt(lineArray[16]);
            int Cars_and_Taxis = Integer.parseInt(lineArray[17]);
            int Buses_and_Coaches = Integer.parseInt(lineArray[18]);
            int Large_goods_vehicles = Integer.parseInt(lineArray[19]);
            int Heavy_goods_vehicles_2_rigid_axle = Integer.parseInt(lineArray[20]);
            int Heavy_goods_vehicles_3_rigid_axle = Integer.parseInt(lineArray[21]);
            int Heavy_goods_vehicles_4_or_more_rigid_axle = Integer.parseInt(lineArray[22]);
            int Heavy_goods_vehicles_3_or_4_articulated_axle = Integer.parseInt(lineArray[23]);
            int Heavy_goods_vehicles_5_articulated_axle = Integer.parseInt(lineArray[24]);
            int Heavy_goods_vehicles_6_articulated_axle = Integer.parseInt(lineArray[25]);
            int All_heavy_goods_vehicles = Integer.parseInt(lineArray[26]);
            int All_motor_vehicles = Integer.parseInt(lineArray[27]);

            insert(id, Direction_of_travel, Count_year, Count_point_hour, Local_authority_name, Road_name,
                    Road_type, Start_Junction_road_name, End_Junction_road_name, Road_Easting, Road_Northing, Road_Latitude,
                    Road_Longitude, Link_length_km, Link_length_miles, Pedal_cycles, Two_wheeled_motor_vehicles, Cars_and_Taxis, Buses_and_Coaches,
                    Large_goods_vehicles, Heavy_goods_vehicles_2_rigid_axle, Heavy_goods_vehicles_3_rigid_axle, Heavy_goods_vehicles_4_or_more_rigid_axle,
                    Heavy_goods_vehicles_3_or_4_articulated_axle, Heavy_goods_vehicles_5_articulated_axle, Heavy_goods_vehicles_6_articulated_axle,
                    All_heavy_goods_vehicles, All_motor_vehicles);
        }
    }

    //this is for the execute query
    public static ResultSet get(int id) {

        String sql = "SELECT * FROM TrafficData WHERE id = " + id;
        ResultSet result = null;

        try {
            Statement statement = connection.createStatement();
            result = statement.executeQuery(sql);
            if (result.next()) {
                System.out.println("TrafficData " + result.getString("Road_name") + " retrived!");
            }
        } catch (Exception e) {
            System.out.println("Error while getting from Traffic data table:" + e.getMessage());
        } finally {
            return result;
        }
    }
}
