/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Jalal 
 */
public class UserTable {

    //insert the information into the table
    public static void insert(String Username, String Password) {

        Connection connection = ConnectDB.DBConnectionUser();

        String sql = "INSERT INTO User (Username, Userpassword) VALUES"
                + "("
                + "'" + Username + "',"
                + "'" + Password + "'"
                + ")";

        //after interering the registration information it will be displayed into the databse
        try {
            Statement statement = connection.createStatement();
            statement.execute(sql);
            System.out.println("User " + Username + " inserted!");
            connection.close();
        } catch (Exception e) {
            System.out.println("Error while inserting into User table:" + e.getMessage());
        }
    }

    // for the execute query
    public static ResultSet get(String Username) {

        Connection connection = ConnectDB.DBConnectionUser();

        String sql = "SELECT * FROM User WHERE Username  = '" + Username + "'";
        ResultSet result = null;

        try {
            Statement statement = connection.createStatement();
            result = statement.executeQuery(sql);
            connection.close();
        } catch (Exception e) {
            System.out.println("Error while getting from User table:" + e.getMessage());
        } finally {
            return result;
        }
    }

    //this is for updatimg the user
    public static void update(String Username, String Password) {

        Connection connection = ConnectDB.DBConnectionUser();

        String sql = " UPDATE User SET Username =  '" + Username + "', Username = '" + "', Password = '" + Password + "' WHERE Username = " + Username;

        try {
            Statement statement = connection.createStatement();
            statement.execute(sql);
            System.out.println("User " + Username + " updated!");
        } catch (Exception e) {
            System.out.println("Error while updating User table: " + e.getMessage());
        }
    }

    // for deleting a user 
    public static void delete(String Username) {

        Connection connection = ConnectDB.DBConnectionUser();

        String sql = " DELETE FROM User WHERE Username = " + Username;

        try {
            Statement statement = connection.createStatement();
            statement.execute(sql);
            System.out.println("User " + Username + " deleted!");
        } catch (Exception e) {
            System.out.println("Error while deleting User table: " + e.getMessage());
        }
    }

    // showing all the user into the system 
    public static ResultSet showAll() {

        Connection connection = ConnectDB.DBConnectionUser();
        ResultSet result = null;

        try {
            Statement statement = connection.createStatement();
            result = statement.executeQuery("Select * from User ");
            int z = 0;
            while (result.next()) {
                int numColumns = result.getMetaData().getColumnCount();
                z++;
                for (int i = 1; i <= numColumns; i++) {
                    System.out.print(" " + result.getObject(i));
                }
                System.out.println("");
            }
        } catch (Exception e) {
            System.out.println("Error showing all data: " + e.getMessage());
        }
        return result;
    }

}
