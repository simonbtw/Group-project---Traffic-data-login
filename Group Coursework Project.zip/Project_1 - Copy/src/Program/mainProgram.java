/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import java.util.ArrayList;

/**
 *
 * @author Jalal  
 * @co-author Subhaan, Tasnim, Simon
 */ 
public class mainProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        CreateTables.createTrafficData();

        LoginGUI loginGUI = new LoginGUI();
        loginGUI.setVisible(true);

        TrafficDataTable.insert(113, "North", 2010, 7, "London", "A444", "Major", "B4561", "A4045", 315403, 198023, 51.67392533, -3.28237762, 7.8, 3.2, 22, 29, 54, 78, 36, 38, 72, 87, 28, 24, 836, 738, 826);
        TrafficDataTable.insert(204, "West", 2017, 15, "Birmingham", "A786", "Major", "B13", "A9007", 318373, 198332, 51.82632938, -3.28280223, 3.0, 3.9, 38, 34, 66, 98, 93, 36, 29, 32, 28, 30, 982, 833, 625);
        TrafficDataTable.insert(346, "South", 2008, 6, "Leeds", "A897", "Minor", "B103", "A97", 320023, 198723, 51.72632954, -3.28260943, 3.0, 4.5, 70, 50, 60, 34, 93, 36, 29, 32, 28, 30, 954, 803, 645);

        ArrayList<String> fileContents = CSVReader.readFile("./TrafficData.csv");

        TrafficDataTable.batchInsert(fileContents);

    }

}
